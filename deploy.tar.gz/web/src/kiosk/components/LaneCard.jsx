import { useApp } from '@/shared/AppContext';

export default function LaneCard({ lane, onEnter }) {
  const { t } = useApp();

  return (
    <div
      className="lane-card"
      onClick={() => onEnter(lane.id)}
      style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: '16px',
        padding: '30px 28px',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        gap: '18px'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div
          style={{
            fontSize: '13px',
            fontWeight: 600,
            letterSpacing: '1.5px',
            textTransform: 'uppercase',
            color: 'var(--muted)'
          }}
        >
          {t.lane}
        </div>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '7px',
            background: 'var(--okbg)',
            color: 'var(--ok)',
            borderRadius: '99px',
            padding: '5px 13px',
            fontSize: '13.5px',
            fontWeight: 600
          }}
        >
          <span
            style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: 'var(--ok)',
              display: 'inline-block'
            }}
          />
          {t.available}
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        <div style={{ fontSize: '76px', fontWeight: 700, lineHeight: 1, color: 'var(--text)' }}>{lane.id}</div>
        {/* target mark: วงกลมซ้อน 64 → 38 → 14px */}
        <div
          style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            border: '2px solid var(--border)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <div
            style={{
              width: '38px',
              height: '38px',
              borderRadius: '50%',
              border: '2px solid var(--muted)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <div style={{ width: '14px', height: '14px', borderRadius: '50%', background: 'var(--accent)' }} />
          </div>
        </div>
      </div>

      <div
        style={{
          borderTop: '1px solid var(--border)',
          paddingTop: '14px',
          fontSize: '14.5px',
          color: 'var(--muted)'
        }}
      >
        {t.enterHint}
      </div>
    </div>
  );
}
