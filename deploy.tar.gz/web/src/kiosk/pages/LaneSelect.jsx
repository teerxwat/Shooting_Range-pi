import { useNavigate } from 'react-router-dom';
import { useApp } from '@/shared/AppContext';
import { getChannels } from '@/kiosk/api';
import { usePoll } from '@/shared/hooks/usePoll';
import Main from '@/shared/components/Main';
import LaneCard from '@/kiosk/components/LaneCard';

function StatusChip({ color, children }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '7px',
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: '99px',
        padding: '7px 14px'
      }}
    >
      <span
        style={{ width: '8px', height: '8px', borderRadius: '50%', background: color, display: 'inline-block' }}
      />
      {children}
    </span>
  );
}

export default function LaneSelect() {
  const { t } = useApp();
  const navigate = useNavigate();
  const { data: channels, error } = usePoll(getChannels, 3000);

  const list = channels || [];
  // ว่าง = กล้อง online และไม่มีใครใช้งานอยู่ (occupied มาจาก heartbeat ของหน้าเว็บที่เปิดช่องนั้น
  // + สถานะ session — ปิดเบราว์เซอร์ไปเฉยๆ backend จะปลดให้เองใน ~15 วิ)
  const available = list.filter((c) => c.online && !c.occupied);
  const busy = list.filter((c) => c.online && c.occupied);
  const offline = list.filter((c) => !c.online);

  return (
    <Main>
      <section>
        <div style={{ display: 'flex', alignItems: 'baseline', flexWrap: 'wrap', gap: '12px', margin: '6px 0 20px' }}>
          <h1 style={{ margin: 0, fontSize: 'clamp(24px, 3vw, 32px)', fontWeight: 700 }}>{t.selectLane}</h1>
          <div style={{ fontSize: '15px', color: 'var(--muted)' }}>
            {available.length} / {list.length} {t.free}
          </div>
        </div>

        {error && (
          <div
            style={{
              padding: '14px 18px',
              borderRadius: '12px',
              border: '1px solid var(--warn)',
              color: 'var(--warn)',
              marginBottom: '18px',
              fontSize: '15px'
            }}
          >
            ⚠ {t.apiDown}
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(270px, 1fr))', gap: '20px' }}>
          {available.map((c) => (
            <LaneCard key={c.channel} lane={{ id: c.channel }} onEnter={(id) => navigate(`/lane/${id}`)} />
          ))}
        </div>

        <div
          style={{
            marginTop: '26px',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '10px',
            alignItems: 'center',
            fontSize: '14px',
            color: 'var(--muted)'
          }}
        >
          {busy.map((c) => (
            <StatusChip key={c.channel} color="var(--warn)">
              {t.lane} {c.channel} — {t.inUse}
            </StatusChip>
          ))}
          {offline.map((c) => (
            <StatusChip key={c.channel} color="var(--muted)">
              {t.lane} {c.channel} — {t.offline}
            </StatusChip>
          ))}
        </div>
      </section>
    </Main>
  );
}
